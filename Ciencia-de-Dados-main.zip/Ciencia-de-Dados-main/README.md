# Ciencia-de-Dados
Oi, , modifiquei como a professora pediu, mas no meu PC não deu bom ver as tabelas, então modifiquei o que eu pude (mesmo que todas as programaçoes estejam certas, muito provavelmente o problema é no meu pc, mas vai entender...)
